#include <iostream>
#include <vector>
#include <set>
#include <iomanip>
#include <math.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <fstream>


using namespace std;
struct inv_st
{
	int input,output,source;
};
class FSM{

	public:
		FSM(string n, int s, int t, int i, int o, int d);
		FSM();
		void setTransition(int so, int in, int ou, int de);
		void addSequence(string s);
		string getID();
		~FSM();
		int getInputs();
		int getDepth();
		int getOutputs();
		int getStates();
		int getTransitions();
		int returnNextState(int s, int i);
		int getNumberOfSequences();
		vector<int> getInputSequence(int i);
		void setCtr(int c);
		void rewardsPush(vector<double> a);
		int getCtr();
		vector<vector<double>> getRewards();
		pair<int,int> getInfo(int s);
	private:
		vector<vector<double>> rewards;
		vector<pair<int,int>> stateInfo;
		vector< vector < vector <int >>> transitions;
		vector< vector < vector <int >>> inv_transitions;
		int ctr;
		int number_of_states;
		int number_of_transitions;
		int number_of_inputs;
		int number_of_outputs;
		int depth;
		string id;
	friend class q;
};
vector<vector<double>> FSM::getRewards()
{
	return rewards;
}
void FSM::rewardsPush(vector<double> v)
{
	rewards.push_back(v);
}
string FSM::getID()
{
	return this->id;
}
vector<int> FSM::getInputSequence(int i)
{
	return vector<int>();
}
void FSM::addSequence(string t)
{
	vector<int> num; 
	for(int i = 0 ; i < t.size() ; i++)
	{
		num.push_back(t[i]-97);
	}
	
}
int FSM::getNumberOfSequences()
{
	return 0;
}
int FSM::getCtr()
{
	return this->ctr;
}
void FSM::setCtr(int c)
{
	this->ctr = c;
}
void FSM::setTransition(int so, int in, int ou, int de)
{	
	
	transitions[so][in][ou]=de;
	
}
pair<int,int> FSM::getInfo(int s)
{
	return stateInfo[s];
}
FSM::FSM(string n, int s, int t, int i, int o, int d)
{
	number_of_states = s;
	number_of_transitions = t;
	number_of_inputs = i;
	number_of_outputs = o;
	depth = d;
	id = n;
	ctr = 0;
	vector<int> ous;
	ous.assign(number_of_outputs,-1);
	transitions.assign(s,vector<vector<int>>(number_of_inputs,ous));

}
FSM::FSM()
{;}
FSM::~FSM()
{
	ctr= 0;
	for(int i = 0 ; i < transitions.size() ; i++){
		transitions[i].clear();		
	}
	
	transitions.clear();
	number_of_inputs = 0 ; 
	number_of_outputs = 0 ;
	number_of_states = 0 ;
	number_of_transitions = 0;
}
int FSM::getInputs()
{
	return this->number_of_inputs;
}
int FSM::getDepth()
{
	return this->depth;
}
int FSM::getTransitions()
{
	return this->number_of_transitions;
}
int FSM::getOutputs()
{
	return this->number_of_outputs;
}
int FSM::getStates()
{
	return this->number_of_states;
}
int FSM::returnNextState(int s, int i)
{	
	for(int j = 0 ; j < number_of_outputs ; j++)
	{
		if(transitions[s][i][j]!=-1)
			return transitions[s][i][j];
	}
	return -1;
}