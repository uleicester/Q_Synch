#include "ReadFSM.h"
#include <vector>
#include <Windows.h>
#include <psapi.h>
#include <algorithm>
using namespace std;
unsigned int not_an_element = INT_MAX;
float DIV = 1048576;
size_t GetMemoryUsageAmount()
{
	PROCESS_MEMORY_COUNTERS_EX pmc;
	DWORD ret = GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));
	if (ret == 0)
	{
		printf("GetProcessMemoryInfo failed with code %d\n", GetLastError());
	}
	
	return pmc.WorkingSetSize;
}

struct Transitions
{
	unsigned int s,e,i;
};
struct PA
{
	vector<Transitions> tr;
	unsigned int sts,ins,trs;
};
class Greedy
{
public:
	Greedy(FSM &f);
	void genSynchSeq();
	vector<int>  getSequence();
	float getMem();
	~Greedy();
private:
	void locate();
	unsigned int getIndex(unsigned int i, unsigned int j);
	void ConstructPairAutomaton();
	void ConstructShortestPaths();
	vector<vector<int>> sPaths;
	vector<vector<int>> end;
	vector<int> order;
	vector<vector<vector<int>>> iPATrans;
	vector<int> destNodes;
	PA myPA;
	unsigned int states;
	unsigned int transitions;
	int inputs;
	FSM fsm;
	float mem;
	vector<int> sequence;
};

Greedy::Greedy(FSM &f)
{
	states = f.getStates();
	transitions = f.getTransitions();
	inputs = f.getInputs();
	sPaths.resize(states*(states-1)/2);
	end.resize(states);
	for(int i = 0 ; i < states; i++)
	{
		vector<int> temp;
		temp.resize(states*(states-1)/2);
		temp.assign(temp.size(),-1);
		end[i]=temp;
	}
	fsm = f;
	
}
float Greedy::getMem()
{
	return mem;
}
void Greedy::ConstructPairAutomaton()
{
	vector<Transitions> pA;
	if(fsm.getID()=="12")
		int ty=0;
	vector<vector<int>> te;
	for(int i = 0 ; i<inputs; i++)
		te.push_back(vector<int>());
	iPATrans.assign(states*(states-1)/2,te);
	unsigned int pAstates = 0;
	for(unsigned int i = 0 ; i < this->states-1; i++)//O(kn^2)
	{		
		for(unsigned int j = i+1 ; j < this->states; j++)
		{
			Transitions t; 
			t.s=getIndex(i,j);
			if(t.s > pAstates)
				pAstates = t.s;// for maxStates;
			for(int k = 0 ; k < this->inputs; k++)
			{
				
				unsigned int nE1 = fsm.returnNextState(i,k);
				unsigned int nE2 = fsm.returnNextState(j,k);
				if(nE1!=nE2)
				{	
					t.e = getIndex(nE1,nE2);
					if(t.e > pAstates)//for maxStates
						pAstates = t.e;
				}
				else
				{
					t.e = not_an_element;//merged states
					destNodes.push_back(t.s);
					if(sPaths[t.s].size()<1){
						sPaths[t.s].push_back(k);
						order.push_back(t.s);
					}
				}
				t.i = k;
				if(t.e!=not_an_element)
					iPATrans[t.e][t.i].push_back(t.s);
				pA.push_back(t);
			}
		}
	}

	

	myPA.ins = this->inputs;
	myPA.sts = pAstates+1;
	myPA.tr = pA;
	myPA.trs=pA.size();
	pA.clear();
	pA.shrink_to_fit();
}
void Greedy::ConstructShortestPaths()
{
	ConstructPairAutomaton();
	vector<int> sources;
	while(destNodes.size()>0)//O(kn^2)
	{
		
		for(unsigned int i = 0 ; i < destNodes.size(); i++)//iterates depth of BFS tree (log(n^2))
		{
			
			for(int j = 0 ; j<inputs ; j++)//iterates k times
			{
				
				for(int l = 0 ; l < iPATrans[destNodes[i]][j].size(); l++)//iterates depth of BFS tree (log(n^2))
				{
					int index = iPATrans[destNodes[i]][j][l];
					if(index>=0 && sPaths[index].size()<1)
					{
						sPaths[index].push_back(j);
						sPaths[index].push_back(destNodes[i]);	
						sources.push_back(index);
						order.push_back(index);
					}
				}
			}
		}

		destNodes.clear();
		destNodes.shrink_to_fit();
		destNodes=sources;
		sources.clear();
		sources.shrink_to_fit();
	}
}
void Greedy::locate()
{
	for(int j = 0 ; j < order.size(); j++)//O(n^3)
	{
		for(int i = 0; i<states; i++)
		{
			if(sPaths[order[j]].size()==1)
			{
				end[i][order[j]]=fsm.returnNextState(i,sPaths[order[j]][0]);
			}
			else
			{
				int temp = fsm.returnNextState(i,sPaths[order[j]][0]);
				int index2= sPaths[order[j]][1];
				end[i][order[j]] = end[temp][index2];
			}
		}
	}
}
unsigned int Greedy::getIndex(unsigned int nextState1, unsigned int nextState2)
{
	if(nextState1>nextState2)
	{
		unsigned int temp = nextState1;
		nextState1 = nextState2;
		nextState2 = temp;
	}
	unsigned int index=0;
	for(unsigned int k = 0 ; k < nextState1; k++)
	{
		index  +=this->states-k-1;
	}
	index+=nextState2-nextState1-1;
	return index;	
}
void Greedy::genSynchSeq()
{
	
	try
	{
		ConstructShortestPaths();
	}
	catch (bad_alloc& badAlloc)
	{
		cerr << "bad_alloc caught, not enough memory: " << badAlloc.what() << endl;
		size_t temp = GetMemoryUsageAmount();
		mem = static_cast<float>(temp);
		mem = mem/DIV;
		//return vector<int>();
	}
	locate();
	vector<int> activeStates;
	for(unsigned int i = 0 ; i < this->states; i++)//O(n)
	{
		activeStates.push_back(i);
	}
	bool cont = true;
	while(cont)//iterates O(n)times
	{
		vector<int> seq;
		int a= -1 ;int b = -1;
		
		for(int i=0; i<states; i++)//O(n)
		{
			if(activeStates[i]>=0 && a<0 && b<0)
				a=activeStates[i];
			else if(activeStates[i]>=0 && a>=0 && b<0)
				b=activeStates[i];
		}


		if(a>=0 && b>=0)
		{
			unsigned int index =  getIndex(a,b);
			sequence.push_back(index);
			
			vector<int> temp;
			temp.resize(states);
			temp.assign(states,-1);
			for(unsigned int j = 0 ; j < activeStates.size() ; j++)//O(n)
			{
				if(activeStates[j]<0)
					;
				else
				{
					unsigned int s = end[activeStates[j]][index];
					temp[s]=s;
				}
			}		
			activeStates.clear();
			activeStates.shrink_to_fit();
			activeStates=temp;
			temp.clear();
			temp.shrink_to_fit();
		}
		else 
			cont = false;
	}
	size_t temp2 = GetMemoryUsageAmount();
	mem = static_cast<float>(temp2);
	mem = mem/DIV;
}
vector<int> Greedy::getSequence()//We do not add this to timing.
{
	vector<int>seqs;
	for(int j=0; j<sequence.size(); j++)
	{
		seqs.push_back(sPaths[sequence[j]][0]);
		if(sPaths[sequence[j]].size()>1)
		{
			bool cc = true;
			int dest = sPaths[sequence[j]][1];
			while(cc)
			{
				seqs.push_back(sPaths[dest][0]);
				if(sPaths[dest].size()==1)
					cc=false;
				else
					dest = sPaths[dest][1];
			}
		}
	}
	int source = 0;
	for(int j=0; j<seqs.size(); j++)
	{
		source = fsm.returnNextState(source,seqs[j]);
	}
	int finalState = source;
	for(int i = 1 ; i<this->states ; i++)
	{
		int source = i;
		for(int j=0; j<seqs.size(); j++)
		{
			source = fsm.returnNextState(source,seqs[j]);
		}
		if(finalState!=source)
			return vector<int>();
	}
	return seqs;
}
Greedy::~Greedy()
{
	sPaths.clear();
	sPaths.shrink_to_fit();
	myPA.tr.clear();
	myPA.tr.shrink_to_fit();
	fsm.~FSM();
}