// Example program
#include <iostream>
#include <string>
#include <vector>
#include <string>
#include <time.h>
#include <fstream>
#include <stdio.h>

#include <chrono>
#include "Greedy.h"

using namespace std;




int main()
{
	ofstream file(/*type the file name to read FSMs*/);
	file<<"FSM,states,inputs,transitions,sequence,length,TrainTime,ProcesTime,TotalTime,Blocks,Memory,Algorithm"<<endl;	
	ReadFSMs reader(/*type the file name to read FSMs*/);
	int i =0;
	int ctr = 0;
	//for(int i = 0 ; i< reader.FSMlist.size() ; i++)
	while(reader.readAnFSM()){
		ctr++;
		cout<<ctr<<" is being processed.."<<endl;
		
		auto start_T_time = std::chrono::high_resolution_clock::now();
		Greedy my_Gr(reader.FSMlist[i]);
		my_Gr.genSynchSeq();
		auto end_T_time = std::chrono::high_resolution_clock::now();
		auto time_T = end_T_time - start_T_time;
		float t_T = time_T/std::chrono::milliseconds(1);
		vector<int>s = my_Gr.getSequence();
		file<<ctr<<" "<<reader.FSMlist[i].getStates()<<" "<<reader.FSMlist[i].getInputs()<<" "<<reader.FSMlist[i].getTransitions();
		if(s.size()==0)
		{
			file<<" NA "<<s.size()<<" "<<t_T<<" "<<my_Gr.getMem()<<endl;
		}
		else 
		{
			file<<" ";
			char buffer[10];
			for(int g = 0; g < s.size()-1 ; g++)
				file<<char(s[g]+97);
			file<<char(s[s.size()-1]+97);
			file<<" "<<s.size()<<" 0 0 "<<t_T<<" 0 "<<my_Gr.getMem()<<" Eppstein"<<endl;
		}
		my_Gr.~Greedy();
		reader.deleteAnFSM();
	}	
	file.close();
	return 0;
}