//#include"ReadFSM.h"
//#include<vector>
//#include <Windows.h>
//#include <psapi.h>
//#include<algorithm>
//using namespace std;
//int not_an_element = INT_MAX;
//float DIV = 1048576;
//int REV = 10000;
//
//struct SET
//{
//	vector<int> STATE;
//	vector<int> rSeq;
//};
//size_t GetMemoryUsageAmount()
//{
//	PROCESS_MEMORY_COUNTERS_EX pmc;
//	DWORD ret = GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));
//	if (ret == 0)
//	{
//		printf("GetProcessMemoryInfo failed with code %d\n", GetLastError());
//	}
//	
//	return pmc.WorkingSetSize;
//}
//class q
//{
//public:
//	q(unsigned long int s, int a, int mtv, double ga, double al, FSM &f);
//	vector<int> genSynchSeq(int l, int maxEpisodes);
//	void train(int ep);
//	int getBlocks();
//	int getEpisodes();
//	float getMem();
//	~q();
//private:
//	int q_learn(unsigned long int &state, int &action,int & episode, vector<int> &seq);
//	int select_best_action(unsigned long int state);
//	double get_best_action_value(unsigned long int state);
//	unsigned long int get_next_state(unsigned long int state, int action, vector<int> &seq);
//	void getNextStates(vector<int> &v, int action);
//	double getReward(unsigned long int state, int action);
//	void vectToInt(vector<int> v, unsigned long int & val, vector<int> &seq);
//	void intToVect(vector<int> & v, unsigned long int val);
//	void createQelem(int index);
//	//int STATES;
//	int ACTIONS;
//	double GAMMA;
//	double ALPHA;
//	vector<vector<double>> Q_TABLE;
//	vector<vector<double>> REWARD;
//	vector<SET> STATES;
//	int MAX_TRAIN_VALUE;
//	FSM fsm;
//	int t_episodes;
//	float mem;
//};
//struct res
//{
//	int ep;
//	double rew;
//	vector<int> se;
//};
//void q::vectToInt(vector<int> v, unsigned long int & val, vector<int> &seq)
//{//sorted unrepeated not empty
//	
//	val = not_an_element;
//	
//	if(v.size()>0)
//	{
//		
//		if(STATES.size()==0)
//		{
//			SET temp;
//			temp.STATE=v;
//			temp.rSeq = seq;
//			STATES.push_back(temp);
//			createQelem(val);
//			val = 0;
//			return;
//		}
//		else
//		{
//			for(int i = 0; i < STATES.size(); i++)
//			{
//				if(STATES[i].STATE.size()==v.size())
//				{			
//					int equalElem = 0;
//					for(int j = 0 ; j < v.size() ; j++)
//					{
//						if(v[j]==STATES[i].STATE[j])
//							equalElem++;
//					}
//					if(equalElem==v.size())
//					{
//						val = i;
//						//if(STATES[i].rSeq.size()!=0)
//						//	seq = STATES[i].rSeq;
//						//else
//						STATES[i].rSeq=seq;
//						return;
//					}
//				}
//			}
//
//			SET temp;
//			temp.STATE=v;
//			temp.rSeq = seq;
//			STATES.push_back(temp);
//			val=STATES.size()-1;
//			createQelem(val);		
//		}
//	}
//}
//q::q(unsigned long int s, int a, int mtv, double ga, double al, FSM &f)
//{
//	mem = 0;
//	t_episodes=0;
//	fsm = f;
//	MAX_TRAIN_VALUE = mtv;
//	
//	ACTIONS=a;
//	GAMMA = ga;
//	ALPHA = al;
//	int states = f.getStates();
//	vector<int> temp;
//	for(int i = 0 ; i<states; i++)
//	{
//		temp.push_back(i);
//	}
//	unsigned long int index = 0;
//	vectToInt(temp,index,vector<int>());
//}
//void q::createQelem(int index)
//{
//	vector<double> temp;
//	for(int i= 0 ; i<ACTIONS ; i++)
//	{
//		temp.push_back(0);
//	}
//	Q_TABLE.push_back(temp);
//}
//double q::get_best_action_value(unsigned long int state)
//{
//	double max_value = 0;
//   
//    for(int i = 0 ; i < ACTIONS ; i++)
//    {
//        if(Q_TABLE[state][i]>max_value)
//        {
//            max_value = Q_TABLE[state][i];
//        }
//    }
//    return max_value;
//}
//int q::select_best_action(unsigned long int state)
//{
//	double max_value = INT_MIN;
//    int return_index = -1;
//	int firstValue = Q_TABLE[state][0];
//	
//	for(int i = 0 ; i < ACTIONS ; i++)
//	{
//		if(Q_TABLE[state][i]>max_value)
//		{
//			max_value = Q_TABLE[state][i];
//			return_index = i;
//		}
//	}
//	if(max_value==0)
//	{
//		vector<int> sts,stsTemp,eqWeights;
//		intToVect(sts,state);
//		stsTemp = sts;
//		int min_val = INT_MAX;
//		int min_ind = 0;
//		for(int i = 0; i<ACTIONS; i++)
//		{
//			getNextStates(sts,i);
//			if(sts.size()<min_val){
//				eqWeights.clear();
//				eqWeights.shrink_to_fit();
//				return_index = i;
//				min_val = sts.size();
//				eqWeights.push_back(i);
//			}
//			else if(sts.size()==min_val)
//			{
//				eqWeights.push_back(i);
//			}
//			sts=stsTemp;
//		}
//		if(eqWeights.size()>1){
//				return_index= eqWeights[rand()%eqWeights.size()];
//		}
//		
//	}
//		
//    return return_index;
//}
//int q::getBlocks()
//{
//	return Q_TABLE.size();
//}
//vector<int> q::genSynchSeq(int l, int maxEpisodes)
//{
//	res re;
//	vector<int> temp;
//	for(int i = 0 ; i<fsm.getStates(); i++)
//	{
//		temp.push_back(i);
//	}
//	unsigned long int i_state;
//	vector<int> sequence;
//	vectToInt(temp,i_state,sequence);
//	
//	int st = i_state;
//	int i_action;
//	int ac = 0;
//	int v = INT_MIN ;
//	for(int h = 0 ; h < ACTIONS; h++)
//	{
//		if(Q_TABLE[i_state][h]>v)
//		{	
//			v=Q_TABLE[i_state][h];
//			i_action = h;
//		}
//	}
//	if(v<0)
//	{
//		return vector<int>();
//	}
//	ac = i_action;
//	sequence.push_back(i_action);
//	int execute = 1;		
//	int episode = 0;				
//	bool found = false;
//	int lim = 0;
//
//	while(execute==1 && episode<maxEpisodes && lim<10000000)
//	{
//		lim++;
//		execute = q_learn(i_state,i_action,episode,sequence);
//					
//		if(execute<1 && sequence.size()>l)
//		{
//			sequence.clear();
//			sequence.shrink_to_fit();
//			i_state = st;
//			i_action= ac;
//			sequence.push_back(i_action);
//			execute =1;
//			episode++;
//		}
//		sequence.push_back(i_action);
//	}	
//	if(episode>=maxEpisodes)
//		return vector<int>();
//	re.ep = episode;
//		
//	for(int ff=0 ; ff<sequence.size(); ff++)
//	{
//		re.se.push_back(sequence[ff]);
//	}
//	
//	int source = 0;
//	for(int j=0; j<re.se.size(); j++)
//	{
//		source = fsm.returnNextState(source,re.se[j]);
//	}
//	int finalState = source;
//	for(int i = 1 ; i<st ; i++)
//	{
//		int source = i;
//		for(int j=0; j<re.se.size(); j++)
//		{
//			source = fsm.returnNextState(source,re.se[j]);
//		}
//		if(finalState!=source)
//			return vector<int>();
//	}
//	t_episodes=re.ep;
//	size_t temp2 = GetMemoryUsageAmount();
//	mem = static_cast<float>(temp2);
//	mem = mem/DIV;
//	return re.se;
//}
//double q::getReward(unsigned long int state, int action)
//{
//	vector<int> v;
//	intToVect(v,state);
//	int old_size = v.size();
//	getNextStates(v,action);
//	int new_size = v.size();
//	if(new_size==0)
//		return -100;
//	if (new_size<old_size && new_size>1)
//		return ((old_size-new_size)*REV)/(fsm.getStates());
//	if(new_size==1)
//		return REV;
//	if(new_size==old_size)
//		return 0;
//}
//void q::getNextStates(vector<int> &v, int action)
//{
//	vector<int> next;
//	for(int i=0; i<v.size(); i++)
//	{
//		int n = fsm.returnNextState(v[i],action); 
//		if(n==-1)
//		{
//			v.clear();
//			v.shrink_to_fit();
//			return;
//		}
//		bool add = true;
//		for(int j=0; j<next.size() ; j++)
//		{
//			if(next[j]==n)
//			{
//				add=false;
//			}
//		}
//		if(add)
//			next.push_back(n);
//	}
//	v.clear();
//	v.shrink_to_fit();
//	sort(next.begin(),next.end());
//	v=next;
//}
//void q::train(int maxEpisodes){
//	
//	unsigned long int i_state = 0;
//	int i_action = rand()%ACTIONS;
//	int execute = 1;
//	int episode = 0;
//	int ctr = 0; 
//	int lim = 0;
//	//vector<int> sequence;
//	while(episode<maxEpisodes)
//	{
//		i_state = 0;
//		i_action= rand()%ACTIONS;
//		//sequence.push_back(i_action);
//		execute =1;
//		while(execute==1 && lim<maxEpisodes)
//		{
//			execute = q_learn(i_state,i_action,episode,vector<int>());
//			//sequence.push_back(i_action);
//			lim++;
//		}
//		episode++;
//	}
//}
//void q::intToVect(vector<int> & v, unsigned long int val)
//{
//	v=STATES[val].STATE;
//}
//int q::q_learn(unsigned long int &state, int &action,int & episode, vector<int> &seq)
//{
//	unsigned long int next_state = get_next_state(state,action,seq);
//	int next_action;
//	int epsilon = rand()%100;
//	
//	if(next_state!=not_an_element)
//	{
//		bool notFound=true;
//		while(notFound)
//		{
//			notFound=false;
//			if(epsilon <=2 )
//				next_action = rand()%ACTIONS;
//			else
//				next_action = select_best_action(next_state);
//			unsigned long int next_state_2 = get_next_state(next_state,next_action,seq);
//			if(next_state_2==not_an_element)
//				notFound = true;
//		}
//		
//		double Reward = getReward(state,action);
//
//		Q_TABLE[state][action]=Q_TABLE[state][action] + ALPHA*( Reward + GAMMA*get_best_action_value(next_state) - Q_TABLE[state][action]);    
//	
//		if(Reward==REV)
//			return 10;
//		if( Reward==-100)
//			return -10;//terminate_f
//
//		state = next_state;
//		action = next_action;
//		return 1;
//	}
//	else
//		Q_TABLE[state][action]=Q_TABLE[state][action] + ALPHA*( -10000 + GAMMA*-10000 - Q_TABLE[state][action]);    
//	return -10;
//}
//unsigned long int q::get_next_state(unsigned long int state, int action, vector<int> &seq)
//{
//	vector<int> v;
//	unsigned long int s=-1;
//	intToVect(v,state);
//	if(v.size()==0)
//		int y=56;
//	getNextStates(v,action);
//	vectToInt(v,s,seq);
//	return s;
//}
//int q::getEpisodes()
//{
//	return t_episodes;
//}
//q::~q()
//{
//	mem = 0;
//	t_episodes = 0;
//	Q_TABLE.clear();
//	Q_TABLE.shrink_to_fit();
//	STATES.clear();
//	STATES.shrink_to_fit();
//	//initialize_Q();
//}
//float q::getMem()
//{
//	return mem;
//}


#include"ReadFSM.h"
#include<vector>
#include <Windows.h>
#include <psapi.h>
#include<algorithm>
using namespace std;
int not_an_element = INT_MAX;
float DIV = 1048576;
int REV = 10000;
size_t GetMemoryUsageAmount()
{
	PROCESS_MEMORY_COUNTERS_EX pmc;
	DWORD ret = GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));
	if (ret == 0)
	{
		printf("GetProcessMemoryInfo failed with code %d\n", GetLastError());
	}
	
	return pmc.WorkingSetSize;
}
class q
{
public:
	q(unsigned long int s, int a, int mtv, double ga, double al, FSM &f);
	vector<int> genSynchSeq(int l, int maxEpisodes);
	void train(int ep);
	int getBlocks();
	int getEpisodes();
	float getMem();
	~q();
private:
	int q_learn(unsigned long int &state, int &action,int & episode);
	int getNextStatesSimulate(vector<int> v, int action);
	int select_best_action(unsigned long int state);
	double get_best_action_value(unsigned long int state);
	unsigned long int get_next_state(unsigned long int state, int action);
	void getNextStates(vector<int> &v, int action);
	double getReward(unsigned long int state, int action);
	void vectToInt(vector<int> v, unsigned long int & val);
	void intToVect(vector<int> & v, unsigned long int val);
	void createQelem(int index);
	//int STATES;
	int ACTIONS;
	double GAMMA;
	double ALPHA;
	vector<vector<double>> Q_TABLE;
	vector<vector<double>> REWARD;
	vector<vector<int>> STATES;
	int MAX_TRAIN_VALUE;
	FSM fsm;
	int t_episodes;
	float mem;
};
struct res
{
	int ep;
	double rew;
	vector<int> se;
};
void q::vectToInt(vector<int> v, unsigned long int & val)
{//sorted unrepeated not empty
	
	val = not_an_element;
	
	if(v.size()>0)
	{
		
		if(STATES.size()==0)
		{
			STATES.push_back(v);
			createQelem(val);
			val = 0;
			return;
		}
		else
		{
			for(int i = 0; i < STATES.size(); i++)
			{
				if(STATES[i].size()==v.size())
				{			
					int equalElem = 0;
					for(int j = 0 ; j < v.size() ; j++)
					{
						if(v[j]==STATES[i][j])
							equalElem++;
					}
					if(equalElem==v.size())
					{
						val = i;
						return;
					}
				}
			}
			STATES.push_back(v);
			val=STATES.size()-1;
			createQelem(val);		
		}
	}
}
q::q(unsigned long int s, int a, int mtv, double ga, double al, FSM &f)
{
	mem = 0;
	t_episodes=0;
	fsm = f;
	MAX_TRAIN_VALUE = mtv;
	
	ACTIONS=a;
	GAMMA = ga;
	ALPHA = al;
	int states = f.getStates();
	vector<int> temp;
	for(int i = 0 ; i<states; i++)
	{
		temp.push_back(i);
	}
	unsigned long int index = 0;
	vectToInt(temp,index);
}
void q::createQelem(int index)
{
	vector<double> temp;
	for(int i= 0 ; i<ACTIONS ; i++)
	{
		temp.push_back(0);
	}
	Q_TABLE.push_back(temp);
}
double q::get_best_action_value(unsigned long int state)
{
	double max_value = 0;
   
    for(int i = 0 ; i < ACTIONS ; i++)
    {
        if(Q_TABLE[state][i]>max_value)
        {
            max_value = Q_TABLE[state][i];
        }
    }
    return max_value;
}
int q::select_best_action(unsigned long int state)
{
	double max_value = INT_MIN;
    int return_index = -1;
	int firstValue = Q_TABLE[state][0];
	
	for(int i = 0 ; i < ACTIONS ; i++)
	{
		if(Q_TABLE[state][i]>max_value)
		{
			max_value = Q_TABLE[state][i];
			return_index = i;
		}
	}
	if(max_value==0)
	{
		vector<int> sts,eqWeights;
		intToVect(sts,state);
		int min_val = INT_MAX;
		int min_ind = -1;
		
		for(int i = 0; i<ACTIONS; i++)
		{
			int t = getNextStatesSimulate(sts,i);
			if(t<min_val && t >-1){
				min_val = t;
				min_ind = i;
				eqWeights.clear();
				eqWeights.shrink_to_fit();
				eqWeights.push_back(i);
			}
			else if(t==min_val)
			{
				eqWeights.push_back(i);
			}
		}
		return_index= eqWeights[rand()%eqWeights.size()];
	}
		
    return return_index;
	//double max_value = INT_MIN;
 //   int return_index = -1;
	//int firstValue = Q_TABLE[state][0];
	//
	//for(int i = 0 ; i < ACTIONS ; i++)
	//{
	//	if(Q_TABLE[state][i]>max_value)
	//	{
	//		max_value = Q_TABLE[state][i];
	//		return_index = i;
	//	}
	//}
	//if(max_value==0)
	//	return_index=rand()%ACTIONS;
 //   return return_index;
}
int q::getBlocks()
{
	return Q_TABLE.size();
}
vector<int> q::genSynchSeq(int l, int maxEpisodes)
{
	res re;
	vector<int> temp;
	for(int i = 0 ; i<fsm.getStates(); i++)
	{
		temp.push_back(i);
	}
	unsigned long int i_state;
	vectToInt(temp,i_state);
	vector<int> sequence;
	int st = i_state;
	int i_action;
	int ac = 0;
	int v = INT_MIN ;
	for(int h = 0 ; h < ACTIONS; h++)
	{
		if(Q_TABLE[i_state][h]>v)
		{	
			v=Q_TABLE[i_state][h];
			i_action = h;
		}
	}
	if(v<0)
	{
		return vector<int>();
	}
	ac = i_action;
	sequence.push_back(i_action);
	int execute = 1;		
	int episode = 0;				
	bool found = false;
	int lim = 0;

	while(execute==1 && episode<maxEpisodes && lim<10000000000)
	{
		lim++;
		execute = q_learn(i_state,i_action,episode);
					
		if(execute<1 && sequence.size()>l)
		{
			sequence.clear();
			sequence.shrink_to_fit();
			i_state = st;
			i_action= ac;
			sequence.push_back(i_action);
			execute =1;
			episode++;
		}
		sequence.push_back(i_action);
	}	
	if(episode>=maxEpisodes)
		return vector<int>();
	re.ep = episode;
		
	for(int ff=0 ; ff<sequence.size(); ff++)
	{
		re.se.push_back(sequence[ff]);
	}
	
	int source = 0;
	for(int j=0; j<re.se.size(); j++)
	{
		source = fsm.returnNextState(source,re.se[j]);
	}
	int finalState = source;
	for(int i = 1 ; i<st ; i++)
	{
		int source = i;
		for(int j=0; j<re.se.size(); j++)
		{
			source = fsm.returnNextState(source,re.se[j]);
		}
		if(finalState!=source)
			return vector<int>();
	}
	t_episodes=re.ep;
	size_t temp2 = GetMemoryUsageAmount();
	mem = static_cast<float>(temp2);
	mem = mem/DIV;
	cout<<source<<endl;
	return re.se;
}
double q::getReward(unsigned long int state, int action)
{
	vector<int> v,v2;
	intToVect(v,state);
	v2=v;
	int old_size = v.size();
	getNextStates(v,action);
	int new_size = v.size();
	if(new_size==0)
		return -100;
	if (new_size<old_size && new_size>1)
		return ((old_size-new_size)*REV)/(fsm.getStates());
	if(new_size==1)
		return REV;
	if(new_size==old_size)
	{
		/*int ctrr = 0;
		for(int i = 0 ; i <v2.size() ; i++)
		{
			if(v[i]!=v2[i])
			{
				ctrr++;
			}
		}
		if(ctrr==0)*/
			return -1;
		/*else
			return 0.1*ctrr;*/
	}
		
}
void q::getNextStates(vector<int> &v, int action)
{
	vector<int> next;
	for(int i=0; i<v.size(); i++)
	{
		int n = fsm.returnNextState(v[i],action); 
		if(n==-1)
		{
			v.clear();
			v.shrink_to_fit();
			return;
		}
		bool add = true;
		for(int j=0; j<next.size() ; j++)
		{
			if(next[j]==n)
			{
				add=false;
			}
		}
		if(add)
			next.push_back(n);
	}
	v.clear();
	v.shrink_to_fit();
	sort(next.begin(),next.end());
	v=next;
}
int q::getNextStatesSimulate(vector<int> v, int action)
{
	if(v.size()==0)
		int gh = 0;
	vector<int> next;
	vector<int> temp = v;
	for(int i=0; i<v.size(); i++)
	{
		int n = fsm.returnNextState(v[i],action); 
		if(n==-1)
		{
			v.clear();
			v.shrink_to_fit();
			return -1;
		}
		bool add = true;
		for(int j=0; j<next.size() ; j++)
		{
			if(next[j]==n)
			{
				add=false;
			}
		}
		if(add)
			next.push_back(n);
	}
	if(next.size()==0)
		int gh = 0 ;
	return next.size();
}
void q::train(int maxEpisodes){
	
	unsigned long int i_state = 0;
	int i_action = rand()%ACTIONS;
	int execute = 1;
	int episode = 0;
	int ctr = 0; 
	int lim = 0;
	while(episode<maxEpisodes)
	{
		i_state = 0;
		i_action= rand()%ACTIONS;
		execute =1;
		while(execute==1 && lim<maxEpisodes)
		{
			execute = q_learn(i_state,i_action,episode);
			lim++;
		}
		episode++;
	}
}
void q::intToVect(vector<int> & v, unsigned long int val)
{
	v=STATES[val];
}
int q::q_learn(unsigned long int &state, int &action,int & episode)
{
	unsigned long int next_state = get_next_state(state,action);
	int next_action;
	int epsilon = rand()%100;
	
	if(next_state!=not_an_element)
	{
		bool notFound=true;
		while(notFound)
		{
			notFound=false;
			if(epsilon <=2 )
				next_action = rand()%ACTIONS;
			else
				next_action = select_best_action(next_state);
			unsigned long int next_state_2 = get_next_state(next_state,next_action);
			if(next_state_2==not_an_element)
				notFound = true;
		}
		
		double Reward = getReward(state,action);

		Q_TABLE[state][action]=Q_TABLE[state][action] + ALPHA*( Reward + GAMMA*get_best_action_value(next_state) - Q_TABLE[state][action]);    
	
		if(Reward==REV)
			return 10;
		if( Reward==-100)
			return -10;//terminate_f

		state = next_state;
		action = next_action;
		return 1;
	}
	else
		Q_TABLE[state][action]=Q_TABLE[state][action] + ALPHA*( -10000 + GAMMA*-10000 - Q_TABLE[state][action]);    
	return -10;
}
unsigned long int q::get_next_state(unsigned long int state, int action)
{
	vector<int> v;
	unsigned long int s=-1;
	intToVect(v,state);
	if(v.size()==0)
		int y=56;
	getNextStates(v,action);
	vectToInt(v,s);
	return s;
}
int q::getEpisodes()
{
	return t_episodes;
}
q::~q()
{
	mem = 0;
	t_episodes = 0;
	Q_TABLE.clear();
	Q_TABLE.shrink_to_fit();
	STATES.clear();
	STATES.shrink_to_fit();
	//initialize_Q();
}
float q::getMem()
{
	return mem;
}