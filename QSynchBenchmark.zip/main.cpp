// Example program
#include <iostream>
#include <string>
#include <vector>
#include <string>
#include <time.h>
#include <fstream>
#include <stdio.h>
#include <chrono>

#include "Q_Header.h"

using namespace std;

double GAMMA=0.889985;
double ALFA=0.9;



int main()
{	
	ofstream file("benchmarkFrr.txt");
	file<<"FSM,states,inputs,transitions,sequence,length,TrainTime,ProcesTime,TotalTime,Blocks,Memory"<<endl;	
	ReadFSMs reader("benchmarkFsms.txt");
	int l =10;
	//for(int i = 0 ; i< reader.FSMlist.size() ; i++)
	int i=0;
	int ctr = 0 ;
	while(reader.readAnFSM())
	{
		ctr++;
		cout<<ctr<<" "<<reader.FSMlist[i].getTransitions()<<" ";
	if(ctr==55)
		int tty = 0 ;
		
			int MAX_TRAIN_VALUE = 0;
			if(reader.FSMlist[i].getStates()<100)
				MAX_TRAIN_VALUE = reader.FSMlist[i].getStates();
			else
				MAX_TRAIN_VALUE = log10(reader.FSMlist[i].getStates())*10;
			srand(time(0));	
			q my_q(reader.FSMlist[i].getStates(),reader.FSMlist[i].getInputs(),MAX_TRAIN_VALUE,GAMMA,ALFA,reader.FSMlist[i]);
			cout<<"Training...   ";
			auto start_T_time = std::chrono::high_resolution_clock::now();
			my_q.train(MAX_TRAIN_VALUE);
			auto end_T_time = std::chrono::high_resolution_clock::now();
			cout<<"Training ends..."<<endl;
			auto start_P_time = std::chrono::high_resolution_clock::now();
			vector<int> s = my_q.genSynchSeq(l,MAX_TRAIN_VALUE);
			auto end_P_time = std::chrono::high_resolution_clock::now();
			auto time_T = end_T_time - start_T_time;
			float t_T = time_T/std::chrono::milliseconds(1);
			auto time_P = end_P_time - start_P_time;
			float t_P = time_P/std::chrono::milliseconds(1);
						
			int ep = my_q.getEpisodes();
	
			file<<ctr<<" "<<reader.FSMlist[i].getStates()<<" "<<reader.FSMlist[i].getInputs()<<" "<<reader.FSMlist[i].getTransitions();

			if(s.size()==0)
			{
				file<<" NA "<<s.size()<<" ";
			}
			else 
			{
				file<<" ";
				char buffer[10];
				for(int g = 0; g < s.size()-1 ; g++)
					file<<s[g]<<" ";//char(+97);//+34);//
				file<<s[s.size()-1];//char(+97);//+34);//
				file<<" "<<s.size()<<" ";
			}
			file<<t_T<<" "<<t_P<<" "<<t_T+t_P<<" "<<my_q.getBlocks()<<" "<<my_q.getMem()<<endl;
			my_q.~q();
		
		reader.deleteAnFSM();
	}	
	file.close();
	return 0;
}